package com.prwa

//import org.apache.spark.{SparkConf,SparkContext}
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;

object WordCount {
  
  def main(args : Array[String]) {
    
    val dp = new SparkConf().setAppName("WordCount").setMaster("local[*]")
    val sc = new SparkContext(dp)
    
    val filename = sc.textFile("file:/home/cloudera/Desktop/file")
    
    val pt = filename.flatMap(lists => lists.split(" ")).
    map(lines => (lines,1)).reduceByKey((a,b) => a+b)
    
    pt.collect.foreach(println)
    sc.stop()
  }
}